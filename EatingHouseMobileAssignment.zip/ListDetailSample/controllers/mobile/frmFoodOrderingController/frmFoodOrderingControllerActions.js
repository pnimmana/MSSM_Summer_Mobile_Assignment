define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for btnBack **/
    AS_Button_e326feb43e0e4f8086d1e9a666bea044: function AS_Button_e326feb43e0e4f8086d1e9a666bea044(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmList");
        ntf.navigate();
    },
    /** onClick defined for flxPhone **/
    AS_FlexContainer_f893c2746cbe4deea70278aa2dea87f8: function AS_FlexContainer_f893c2746cbe4deea70278aa2dea87f8(eventobject) {
        var self = this;
        this.view.flxPopup.isVisible = true;
        this.view.flxcallusat.isVisible = true;
        this.view.flxmailusat.isVisible = false;
        this.view.flxlocateusat.isVisible = false;
    },
    /** onTouchEnd defined for ImgMail **/
    AS_Image_bd42a110a3b544d99b4781a0f00e76b8: function AS_Image_bd42a110a3b544d99b4781a0f00e76b8(eventobject, x, y) {
        var self = this;
    },
    /** onClick defined for flxMail **/
    AS_FlexContainer_da802bd5a867446cad4f4f3eb8b96abc: function AS_FlexContainer_da802bd5a867446cad4f4f3eb8b96abc(eventobject) {
        var self = this;
        this.view.flxPopup.isVisible = true;
        this.view.flxcallusat.isVisible = false;
        this.view.flxmailusat.isVisible = true;
        this.view.flxlocateusat.isVisible = false;
    },
    /** onClick defined for flxMaps **/
    AS_FlexContainer_b59520c22575427fbf24cdac7a335128: function AS_FlexContainer_b59520c22575427fbf24cdac7a335128(eventobject) {
        var self = this;
        this.view.flxPopup.isVisible = true;
        this.view.flxcallusat.isVisible = false;
        this.view.flxmailusat.isVisible = false;
        this.view.flxlocateusat.isVisible = true;
    },
    /** onClick defined for flxPopup **/
    AS_FlexContainer_cc2e34a6573b4d7d97cfd2179b84fb74: function AS_FlexContainer_cc2e34a6573b4d7d97cfd2179b84fb74(eventobject) {
        var self = this;
        this.view.flxPopup.isVisible = false;
    }
});