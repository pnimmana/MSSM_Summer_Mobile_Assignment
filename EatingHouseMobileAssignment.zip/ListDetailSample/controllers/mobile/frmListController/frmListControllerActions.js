define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onRowClick defined for segItems **/
    AS_Segment_f8cbda517b184b299b8a575e43b96c36: function AS_Segment_f8cbda517b184b299b8a575e43b96c36(eventobject, sectionNumber, rowNumber) {
        var self = this;
        var ntf = new kony.mvc.Navigation("undefined");
        ntf.navigate();
    }
});